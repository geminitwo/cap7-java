/**
 * 
 */
package com.fiap.healthtrack;

/**
 * @author Anq001
 *
 */
public class Peso {
	/**
	 * Usuario a quem pertence o registro
	 */
	private Usuario regUser;
	/**
	 * Peso em quilogramas do usu�rio
	 */
	private float peso;
	/**
	 * Data em que ocorreu o registro
	 */
	private String data;

	/**
	 * 
	 */
	public Peso() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Cria um novo obejto de registro de peso corporal
	 * @param regUser Usuario a quem pertence o registro
	 * @param peso Peso em quilogramas do usu�rio
	 * @param data Data em que ocorreu o registro
	 */
	public void registroPeso(Usuario regUser, float peso, String data) {
		this.regUser = regUser;
		this.peso = peso;
		this.data = data;
	}

	/**
	 * @return the regUser
	 */
	public Usuario getRegUser() {
		return regUser;
	}

	/**
	 * @param regUser the regUser to set
	 */
	public void setRegUser(Usuario regUser) {
		this.regUser = regUser;
	}

	/**
	 * @return the peso
	 */
	public float getPeso() {
		return peso;
	}

	/**
	 * @param peso the peso to set
	 */
	public void setPeso(float peso) {
		this.peso = peso;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

}
