/**
 * 
 */
package com.fiap.healthtrack;

/**
 * @author Anq001
 *
 */
public class Teste {

	/**
	 * 
	 */
	public Teste() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args null
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Usuario user = new Usuario();
		user.CadastrarUsuario("Nome Teste", "10/03/1965", "email@email.com", "senha123", "Masculino", 1.85, 85);
		
		AtividadeFisica regAtvFisica = new AtividadeFisica();
		regAtvFisica.registroAtividadeFisica(user, "Caminhada", "descri��o...", 1250.5, "10/02/2022");
		
		PressaoArterial regPressaoArt = new PressaoArterial();
		regPressaoArt.registroPressaoArterial(user, 12, 8, "10/02/2022");
		
		Peso regPeso = new Peso();
		regPeso.registroPeso(user, 85, "10/02/2022");
		
		Alimentacao regAlimento = new Alimentacao();
		regAlimento.registroAlimenta��o(user, "Almo�o", "descri��o...", 1115, "10/02/2022");
		

		System.out.println("Nome: " + user.getNome());
		System.out.println("IMC: " + user.getIMC());
		System.out.println("Press�o arterial: " + regPressaoArt.getSistolica()+"/"+regPressaoArt.getDiastolica()+"mmHg" );
		System.out.println("Peso: " + regPeso.getPeso()+"kg");

	}
}
