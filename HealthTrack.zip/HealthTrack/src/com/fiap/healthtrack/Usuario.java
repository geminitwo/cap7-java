/**
 * 
 */
package com.fiap.healthtrack;

/**
 * @author Anq001
 *
 */
public class Usuario {
	/**
	 * Nome do usu�rio
	 */
	private String nome;
	/**
	 * Data de nascimento
	 */
	private String dataNascimento;
	/**
	 * E-mail
	 */
	private String email;
	/**
	 * Senha
	 */
	private String senha;
	/**
	 * G�nero do usu�rio
	 */
	private String genero;
	/**
	 * Altura em metros
	 */
	private double altura;
	/**
	 * Peso em quilos
	 */
	private double peso;
	
	/**
	 * 
	 */
	public Usuario() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Cria��o de conta
	 * @param nome Nome do usu�rio
	 * @param dataNascimento Data de nascimento do usu�rio
	 * @param email E-mail do usu�rio
	 * @param senha Senha do usu�rio
	 * @param genero G�nero do usu�rio
	 * @param altura Altura do usu�rio
	 * @param peso Peso do usu�rio
	 */
	public void CadastrarUsuario(String nome, String dataNascimento, String email, String senha, String genero, double altura, double peso) {
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.email = email;
		this.senha = senha;
		this.genero = genero;
		this.altura = altura;
		this.peso = peso;
		System.out.println("Usu�rio " + this.nome + " cadastrado!");
	}
	
	/**
	 * @return Retorna o IMC do usu�rio
	 */
	public double getIMC() {
		double imc = this.peso/(this.altura*this.altura);
		imc = (double)Math.round(imc*100d)/100d;
		return imc;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the dataNascimento
	 */
	public String getDataNascimento() {
		return dataNascimento;
	}

	/**
	 * @param dataNascimento the dataNascimento to set
	 */
	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the senha
	 */
	public String getSenha() {
		return senha;
	}

	/**
	 * @param senha the senha to set
	 */
	public void setSenha(String senha) {
		this.senha = senha;
	}

	/**
	 * @return the genero
	 */
	public String getGenero() {
		return genero;
	}

	/**
	 * @param genero the genero to set
	 */
	public void setGenero(String genero) {
		this.genero = genero;
	}

	/**
	 * @return the altura
	 */
	public double getAltura() {
		return altura;
	}

	/**
	 * @param altura the altura to set
	 */
	public void setAltura(double altura) {
		this.altura = altura;
	}

	/**
	 * @return the peso
	 */
	public double getPeso() {
		return peso;
	}

	/**
	 * @param peso the peso to set
	 */
	public void setPeso(double peso) {
		this.peso = peso;
	}

}
