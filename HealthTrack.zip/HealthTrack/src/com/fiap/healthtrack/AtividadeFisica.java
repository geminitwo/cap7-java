/**
 * 
 */
package com.fiap.healthtrack;

/**
 * @author Anq001
 *
 */
public class AtividadeFisica {
	/**
	 * Usuario que realizou a atividade
	 */
	private Usuario regUser;
	/**
	 * O tipo de atividade f�sica (caminhada, corrida, pedalada, muscula��o, etc)
	 */
	private String tipo;
	/**
	 * Descri��o da atividade f�sica
	 */
	private String descricao;
	/**
	 * Calorias gastas na atividade f�sica
	 */
	private double caloriaGasta;
	/**
	 * Data em que ocorreu a atividade f�sica
	 */
	private String data;

	/**
	 * 
	 */
	public AtividadeFisica() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Cria um novo obejto de registro de Atividade F�sica
	 * @param regUser Usu�rio que realizou a atividade
	 * @param tipo Tipo de atividade (caminhada, corrida, pedalada, muscula��o, etc)
	 * @param descricao Breve descri��o da atividade
	 * @param caloriaGasta Quantidade gasta de calorias
	 * @param data Data em que ocorreu a atividade
	 */
	public void registroAtividadeFisica(Usuario regUser, String tipo, String descricao, double caloriaGasta, String data) {
		this.regUser = regUser;
		this.tipo = tipo;
		this.descricao = descricao;
		this.caloriaGasta = caloriaGasta;
		this.data = data;
	}

	/**
	 * @return the regUser
	 */
	public Usuario getRegUser() {
		return regUser;
	}

	/**
	 * @param regUser the regUser to set
	 */
	public void setRegUser(Usuario regUser) {
		this.regUser = regUser;
	}

	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the caloriaGasta
	 */
	public double getCaloriaGasta() {
		return caloriaGasta;
	}

	/**
	 * @param caloriaGasta the caloriaGasta to set
	 */
	public void setCaloriaGasta(double caloriaGasta) {
		this.caloriaGasta = caloriaGasta;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

}
