/**
 * 
 */
package com.fiap.healthtrack;

/**
 * @author Anq001
 *
 */
public class PressaoArterial {
	/**
	 * Usuario a quem pertence o registro
	 */
	private Usuario regUser;
	/**
	 * press�o sist�lica
	 */
	private int sistolica;
	/**
	 * press�o diast�lica
	 */
	private int diastolica;
	/**
	 * Data em que ocorreu o registro
	 */
	private String data;

	/**
	 * 
	 */
	public PressaoArterial() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Cria um novo objeto de registro de press�o arterial
	 * @param regUser Usuario a quem pertence o registro
	 * @param sistolica press�o sist�lica
	 * @param diastolica press�o diast�lica
	 * @param data Data em que ocorreu o registro
	 */
	public void registroPressaoArterial(Usuario regUser, int sistolica, int diastolica, String data) {
		this.regUser = regUser;
		this.sistolica = sistolica;
		this.diastolica = diastolica;
		this.data = data;
	}

	/**
	 * @return the regUser
	 */
	public Usuario getRegUser() {
		return regUser;
	}

	/**
	 * @param regUser the regUser to set
	 */
	public void setRegUser(Usuario regUser) {
		this.regUser = regUser;
	}

	/**
	 * @return the sistolica
	 */
	public int getSistolica() {
		return sistolica;
	}

	/**
	 * @param sistolica the sistolica to set
	 */
	public void setSistolica(int sistolica) {
		this.sistolica = sistolica;
	}

	/**
	 * @return the diastolica
	 */
	public int getDiastolica() {
		return diastolica;
	}

	/**
	 * @param diastolica the diastolica to set
	 */
	public void setDiastolica(int diastolica) {
		this.diastolica = diastolica;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

}
