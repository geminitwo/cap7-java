/**
 * 
 */
package com.fiap.healthtrack;

/**
 * @author Anq001
 *
 */
public class Alimentacao {
	/**
	 * Usuario que realizou a atividade
	 */
	private Usuario regUser;
	/**
	 * O tipo de alimenta��o (cafe, almo�o, janta, lanche, fruta, etc)
	 */
	private String tipo;
	/**
	 * Descri��o do que foi consumido (opcional)
	 */
	private String descricao;
	/**
	 * Calorias consumidas
	 */
	private double caloriaConsumida;
	/**
	 * Data em que ocorreu o consumo
	 */
	private String data;

	/**
	 * 
	 */
	public Alimentacao() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Cria um novo obejto de registro de Alimenta��o
	 * @param regUser Usu�rio que realizou a atividade
	 * @param tipo Tipo de alimenta��o (cafe, almo�o, janta, lanche, fruta, etc)
	 * @param descricao Breve descri��o da atividade
	 * @param caloriaConsumida Quantidade consumidas de calorias
	 * @param data Data em que ocorreu o consumo
	 */
	public void registroAlimenta��o(Usuario regUser, String tipo, String descricao, double caloriaConsumida, String data) {
		this.regUser = regUser;
		this.tipo = tipo;
		this.descricao = descricao;
		this.caloriaConsumida = caloriaConsumida;
		this.data = data;
	}

	/**
	 * @return the regUser
	 */
	public Usuario getRegUser() {
		return regUser;
	}

	/**
	 * @param regUser the regUser to set
	 */
	public void setRegUser(Usuario regUser) {
		this.regUser = regUser;
	}

	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the caloriaConsumida
	 */
	public double getCaloriaConsumida() {
		return caloriaConsumida;
	}

	/**
	 * @param caloriaConsumida the caloriaConsumida to set
	 */
	public void setCaloriaConsumida(double caloriaConsumida) {
		this.caloriaConsumida = caloriaConsumida;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

}
